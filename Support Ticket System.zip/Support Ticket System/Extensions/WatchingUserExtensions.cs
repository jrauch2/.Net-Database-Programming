﻿namespace Support_Ticket_System
{
    using System;
    using System.Collections.Generic;

    public partial class WatchingUser
    {
        public override string ToString()
        {
            return this.User.ToString();
        }
    }
}