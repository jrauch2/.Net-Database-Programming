﻿namespace Support_Ticket_System.Enums
{
    public enum Severity
    {
        Tier1 = 1, Tier2 = 2,  Tier3 = 3
    }
}