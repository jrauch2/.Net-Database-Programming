﻿namespace Support_Ticket_System.Enums
{
    public enum Status
    {
        Open, Closed
    }
}