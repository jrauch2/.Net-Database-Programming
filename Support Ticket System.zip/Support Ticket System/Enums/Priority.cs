﻿namespace Support_Ticket_System.Enums
{
    public enum Priority
    {
        Low, Medium, High, Severe
    }
}